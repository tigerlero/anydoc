create function earth_distance(earth, earth)
  returns double precision
immutable
strict
language sql
as $$
SELECT sec_to_gc(cube_distance($1, $2))
$$;

